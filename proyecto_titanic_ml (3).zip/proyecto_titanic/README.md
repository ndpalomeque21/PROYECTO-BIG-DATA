# Comparación de Modelos y Optimización de Pipeline — Dataset Titanic

**Universidad Católica de Santiago de Guayaquil** · Facultad de Economía y Empresa · Administración de Empresas
**Asignatura:** Big Data · **Docente:** Mtr. Xavier Alejandro Jacome Piñeiros · **Periodo:** VII Ciclo - A 2026
**Integrantes:** William Sebastian Augurto Cedeño · Jesus Anthony Tinoco León · Nadia Marcela Palomeque Pérez

Proyecto de la asignatura **Big Data** (UCSG). Construye un pipeline de
clasificación reproducible y **sin *data leakage*** para predecir la supervivencia de los
pasajeros del Titanic, comparando cuatro algoritmos con búsqueda de hiperparámetros,
métricas completas, análisis de overfitting e importancia de variables.

## Estructura del repositorio

```
.
├── notebook.ipynb      # Notebook principal (ejecutable de principio a fin)
├── titanic.csv         # Dataset (incluido para reproducibilidad offline)
├── informe.pdf         # Informe final (PDF)
├── informe.md          # Informe final (Markdown)
├── resultados.json     # Métricas exportadas por el notebook
└── figuras/            # Gráficos generados (ROC, matriz de confusión, etc.)
```

## Cómo ejecutar

1. Instalar dependencias:
   ```bash
   pip install pandas numpy scikit-learn matplotlib
   ```
2. Abrir `notebook.ipynb` y ejecutar **Kernel → Restart & Run All**.

El notebook corre **sin conexión a internet** porque `titanic.csv` está incluido. Todo el
preprocesamiento está encapsulado en un `Pipeline` de scikit-learn; el conjunto de prueba
no participa en el entrenamiento ni en la búsqueda de hiperparámetros.

## Resultados principales

- **Modelos comparados:** Árbol de Decisión, Random Forest, Gradient Boosting y Regresión Logística.
- **Búsqueda de hiperparámetros:** `GridSearchCV` con `cv=5`, métrica de selección `roc_auc`.
- **Mejor modelo:** Regresión Logística — AUC-ROC **0.868** en prueba, F1 macro 0.827 y la
  menor brecha de overfitting (0.014). Un modelo simple con buen feature engineering supera
  a los ensambles en generalización.

## Integrantes

| Integrante | Tareas |
|---|---|
| William Sebastian Augurto Cedeño | Carga y exploración de datos y feature engineering |
| Jesus Anthony Tinoco León | Pipeline, definición de modelos y búsqueda de hiperparámetros |
| Nadia Marcela Palomeque Pérez | Evaluación, overfitting, importancia de variables e informe |
