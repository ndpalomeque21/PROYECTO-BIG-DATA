<div align="center">

# “UNIVERSIDAD CATÓLICA SANTIAGO DE GUAYAQUIL”

**FACULTAD DE ECONOMÍA Y EMPRESA**

**ADMINISTRACIÓN DE EMPRESAS**

<br>

**ASIGNATURA:**<br>
Big Data

**TEMA:**<br>
Comparación de Modelos y Optimización de Pipeline en el Dataset Titanic

**INTEGRANTES:**<br>
William Sebastian Augurto Cedeño<br>
Jesus Anthony Tinoco León<br>
Nadia Marcela Palomeque Pérez

**DOCENTE:**<br>
Mtr. Xavier Alejandro Jacome Piñeiros

**PERIODO:**<br>
VII CICLO - A 2026

<br>

**ECUADOR**

</div>

---

## Introducción

El hundimiento del Titanic en 1912 constituye un problema clásico de clasificación binaria, ya que se busca predecir si un pasajero sobrevivió a partir de sus características; si bien en clases se construyó un primer clasificador con imputación básica, codificación de variables categóricas y un único modelo, este quedó sin una validación seria que confirmara si era realmente la mejor opción, de modo que el presente trabajo retoma ese punto de partida para llevarlo mucho más lejos. Con ese fin se diseñó un pipeline reproducible y libre de fuga de información (data leakage) en scikit-learn (Pedregosa et al., 2011), al que se incorporaron variables nuevas debidamente justificadas, mientras que la comparación se amplió a cuatro algoritmos evaluados bajo condiciones idénticas y la optimización de hiperparámetros se realizó de forma sistemática mediante GridSearchCV con cinco particiones; asimismo, la evaluación trascendió el accuracy para incorporar la precisión, el recall, el F1 y el AUC-ROC, junto con un análisis del overfitting y de la importancia de las variables. El conjunto de datos del Titanic (Kaggle, s.f.) reúne 891 pasajeros y presenta un desbalance del 61.6 % que no sobrevivió frente al 38.4 % que sí lo logró, razón por la cual se dividió de manera estratificada en 712 casos de entrenamiento y 179 de prueba; estos últimos se reservaron por completo y no intervinieron ni en el ajuste ni en la selección de hiperparámetros, de modo que las métricas reportadas reflejan el desempeño sobre datos no vistos.

## Ingeniería de Características Aplicada

El proceso partió del feature engineering visto en clases —el título extraído del nombre, el tamaño del grupo familiar y un indicador de cabina— y, sobre esa base, se añadieron variables nuevas, cada una justificada por el aporte predictivo esperado. Así, *FarePerPerson* surge de dividir la tarifa entre el tamaño del grupo, puesto que el valor registrado corresponde al billete completo y no a cada persona, de manera que aísla el nivel socioeconómico individual, ligado al acceso a mejores cubiertas y a los botes salvavidas; en la misma línea, *IsAlone* distingue a quienes viajaban solos, ya que la presencia de familiares modificaba la dinámica de evacuación y resume de forma no lineal el tamaño del grupo. A su vez, la interacción *Pclass x Age* recoge que el efecto de la edad dependía de la clase, dado que un niño de primera no enfrentaba las mismas probabilidades que uno de tercera, mientras que *Deck* —la cubierta, obtenida de la primera letra de la cabina— y *Title* —Mr, Mrs, Miss, Master o Rare— aportan la ubicación física en el barco y un resumen del sexo, la edad aproximada y el estatus social. Conviene subrayar que todo el procesamiento se implementó como un transformador fila a fila y sin estado, primer paso del pipeline, por lo cual, al depender cada variable solo de los datos del propio pasajero, no se introduce fuga de información; del mismo modo, la imputación por mediana y moda, el escalado estándar y la codificación one-hot se ajustan únicamente con los datos de entrenamiento de cada partición dentro de un ColumnTransformer apoyado en pandas (McKinney, 2010), lo que garantiza la ausencia de data leakage.

## Resultados

La Tabla 1 reúne, sobre el conjunto de prueba, las métricas de los cuatro modelos con sus mejores hiperparámetros, y de su lectura se desprende que todos superan ampliamente el azar (AUC = .50); no obstante, la Regresión Logística alcanza el mejor desempeño en cada indicador, con un AUC de .87, de modo que su ventaja sobre los ensambles revela que, en este caso, una mayor capacidad de representación no se traduce en una mejor generalización.

**Tabla 1.** *Métricas de Desempeño de los Modelos sobre el Conjunto de Prueba*

| Modelo | Accuracy | Precisión | Recall | F1 | AUC-ROC |
|---|---|---|---|---|---|
| Regresión Logística | .8380 | .8323 | .8223 | .8265 | .8682 |
| Gradient Boosting | .8156 | .8097 | .7960 | .8014 | .8480 |
| Random Forest | .7989 | .7964 | .7715 | .7796 | .8479 |
| Árbol de Decisión | .8212 | .8107 | .8167 | .8132 | .8476 |

*Nota.* Precisión, Recall y F1 corresponden al promedio macro. El mejor modelo fue la Regresión Logística.

![Curvas ROC](figuras/curvas_roc.png)

**Figura 1.** *Curvas ROC de los Cuatro Modelos sobre el Conjunto de Prueba*

Las curvas ROC de la Figura 1 confirman esa impresión, puesto que, aunque los cuatro modelos se separan con claridad de la diagonal, la Regresión Logística domina ligeramente en la zona de bajas tasas de falsos positivos, que es la región más relevante cuando interesa identificar sobrevivientes cometiendo pocos errores.

![Matriz de confusión](figuras/matriz_confusion.png)

**Figura 2.** *Matriz de Confusión del Mejor Modelo (Regresión Logística)*

En esa misma dirección, la matriz de confusión (Figura 2) detalla que, de los 179 pasajeros de prueba, se acertaron 98 no sobrevivientes y 52 sobrevivientes frente a 12 falsos positivos y 17 falsos negativos; dicho de otro modo, el modelo identifica correctamente al 75 % de los sobrevivientes y al 89 % de quienes no lo fueron, de suerte que los falsos negativos constituyen el error más costoso del análisis.

En cuanto al overfitting, la Tabla 2 contrasta el accuracy de entrenamiento con el de validación cruzada, de manera que una brecha amplia delata el sobreajuste. Con los parámetros por defecto, los modelos de árbol lo manifiestan de forma severa, ya que el árbol simple alcanza .99 en entrenamiento pero apenas .79 en validación —una brecha de .20—; sin embargo, la búsqueda de hiperparámetros lo atenuó al limitar la profundidad, con lo que esa diferencia se redujo a .02. Tras el ajuste, Random Forest y Gradient Boosting conservan las mayores brechas (.08 y .10), algo coherente con su elevada capacidad, mientras que la Regresión Logística casi no sobreajusta (.01) gracias a su baja varianza; en consecuencia, el sobreajuste se mitigó combinando la regularización por hiperparámetros con la validación cruzada estratificada empleada para seleccionar configuraciones que generalizan.

**Tabla 2.** *Accuracy de Entrenamiento y de Validación Cruzada por Modelo*

| Modelo | Entrenamiento | Validación cruzada | Brecha |
|---|---|---|---|
| Árbol de Decisión | .843 | .825 | .018 |
| Random Forest | .904 | .822 | .083 |
| Gradient Boosting | .923 | .827 | .095 |
| Regresión Logística | .840 | .826 | .014 |

*Nota.* Brecha = accuracy de entrenamiento menos accuracy de validación cruzada de cinco particiones.

![Importancia de variables](figuras/importancia_variables.png)

**Figura 3.** *Diez Variables Más Importantes del Mejor Modelo (Regresión Logística)*

Por último, la importancia de variables (Figura 3), estimada a partir de la magnitud de los coeficientes estandarizados, sitúa en los primeros lugares al título Mr, que reduce la probabilidad de sobrevivir, y a Master, que la incrementa por tratarse de niños, seguidos del sexo, la cubierta y la clase; estos resultados resultan coherentes con el contexto histórico, dado que la norma de evacuación «mujeres y niños primero» explica el peso del sexo y de los títulos, mientras que Pclass y Deck reflejan que tanto el estatus socioeconómico como la cercanía a los botes condicionaron el acceso a la evacuación.

## Conclusiones

A la luz de la evidencia se recomienda la Regresión Logística, puesto que no solo obtuvo el mejor desempeño en prueba en todas las métricas (AUC = .87), sino que además exhibió la menor brecha de overfitting (.01) y, por tanto, la mejor generalización, a lo que se suma su condición de modelo más interpretable —sus coeficientes son log-odds— y de menor costo computacional; en este sentido, el caso ilustra que un modelo sencillo respaldado por un buen feature engineering puede igualar o superar a alternativas más complejas, hasta el punto de que Gradient Boosting logró el mejor AUC en validación cruzada (.90) y, aun así, no generalizó mejor sobre la prueba, lo que recuerda que la métrica más alta en validación no garantiza el mejor resultado fuera de muestra.

Ahora bien, el análisis no está exento de limitaciones, ya que el conjunto de prueba es reducido —179 casos—, de manera que diferencias de AUC del orden de .02 caen dentro del margen de variabilidad de una sola partición y no pueden considerarse concluyentes; a ello se añade que no se aprovechó el número de ticket, útil para reconocer grupos de viaje no familiares, y que la imputación de la edad por la mediana podría sesgar la interacción Pclass x Age, habida cuenta de que cerca del 20 % de las edades faltaba.

Finalmente, de disponer de más tiempo, se emprendería una validación cruzada repetida o anidada acompañada de pruebas estadísticas para cuantificar la incertidumbre de cada métrica, además de una imputación más fina de la edad —por título y clase—, la calibración de las probabilidades y el ajuste del umbral de decisión según el costo de los falsos negativos, sin descartar la incorporación de XGBoost o LightGBM ni la exploración de ensamblado por stacking.

## Referencias

- Kaggle. (s.f.). *Titanic: Machine learning from disaster* [Conjunto de datos]. https://www.kaggle.com/c/titanic
- McKinney, W. (2010). Data structures for statistical computing in Python. *Proceedings of the 9th Python in Science Conference*, 56–61.
- Pedregosa, F., et al. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research, 12*, 2825–2830.
